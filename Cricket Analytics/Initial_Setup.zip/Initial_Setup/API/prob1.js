const csv = require('csv-parser');
const fs = require('fs');

var countObj = {}

module.exports = function (req, res) {
    /*write your code here*/
}