const csv = require('csv-parser');
const fs = require('fs');

var matchObj = {}
var finalObj = {}
var nfinalObj = {}
var batsman_runs = 0;
var total_runs = 0;
var temp_4 = 0;
var temp_6 = 0;

module.exports = function (req, res) {
    /*write your code here*/
}