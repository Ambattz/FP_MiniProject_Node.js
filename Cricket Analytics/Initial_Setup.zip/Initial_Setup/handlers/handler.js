module.exports = {
    prob1: require('../API/prob1.js'),
    prob2: require('../API/prob2.js'),
    prob3: require('../API/prob3.js'),
    prob4: require('../API/prob4.js')
}